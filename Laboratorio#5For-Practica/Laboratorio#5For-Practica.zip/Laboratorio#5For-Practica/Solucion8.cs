﻿using System;

namespace Laboratorio5
{
    public static class Solucion8
    {
        public static void ImprimirLosNúmerosImparesEntre1Y20()
        {
            for(int i = 1 ; i <= 20 ; i += 2)
            {
                Console.WriteLine(i);
            }
            
        }
    }
}
