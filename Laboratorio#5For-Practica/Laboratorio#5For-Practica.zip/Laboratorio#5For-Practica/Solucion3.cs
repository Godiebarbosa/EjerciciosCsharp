﻿using System;

namespace Laboratorio5
{
    public static class Solucion3
    {
      public static void Imprimir10NumPares()
      { 
      for (int i = 1; i <= 10; i++)
        {
          Console.WriteLine(i * 2);
        }
      }
   }
}