﻿using System;

namespace Laboratorio5
{
    public static class Solucion1
    {
        public static void imprimeNumeros1a10()
        {
            for(int i = 1 ; i <= 10; i++)
            {
                Console.WriteLine(i);//C mayusculas W mayuscula L mayuscula o tira error.
            }
        }
    }
}
