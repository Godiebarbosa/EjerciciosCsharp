﻿using System;

namespace Laboratorio5
{
    public static class Solucion11
    {
        public static void ImprimirNúmerosDel1Al10While()
        {
            int i=1;//inicializamos i en 1
            //mientras i sea menor o igual a 10
            while (i<=10)
            {
                Console.WriteLine(i);
                i++; //Incrementamos i en 1
            }
        }

    }
}